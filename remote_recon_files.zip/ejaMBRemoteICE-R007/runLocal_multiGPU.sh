#!/bin/bash

progname="ejaMBRemoteICE"
pathname="."

# 0.0.0.0 listens on all configured addresses
# can specify a single address to listen on instead
ip="25.1.1.3"
port=10000

# example configurations for multiple GPUs

# this example would use the first and second CUDA devices,
# executing one thread at a time on each device
# (same behavior as gpudevices=2, cf. runLocal_GPU.sh)
cputhreads=0
gputhreads=1
gpudevicelist="0,1"

# this example would use only the third and fourth CUDA devices
# in a system with at least four CUDA devices, still
# executing one thread at a time on each device
#cputhreads=0
#gputhreads=1
#gpudevicelist="2,3"

# this example would use only the third and fourth CUDA devices
# in a system with at least four CUDA devices, but now executing
# two threads at a time on each device (may offer improved performance
# on K20 or better cards--K80 may use 2-4?)
#cputhreads=0
#gputhreads=2
#gpudevicelist="2,3"

LD_LIBRARY_PATH=${pathname}
export LD_LIBRARY_PATH

echo Starting ${progname} "->" messages output to local terminal
${pathname}/${progname} $port --address $ip --cpu-threads $cputhreads --gpu-threads $gputhreads --gpu-device-list $gpudevicelist --verbose
