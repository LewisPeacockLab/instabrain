#!/bin/bash
#
# Author: E. Auerbach, CMRR, 2013-14
#
# /opt/med/config/scripts/med.rc.0/eja_config10GbE.sh
#
# This script configures the 10GbE network adapter installed by the
# local site, which is used for fast remote assisted image recon.
# VB-line version.
#
#
# Shell functions sourced from /etc/rc.status:
#      rc_check         check and set local and overall rc status
#      rc_status        check and set local and overall rc status
#      rc_status -v     ditto but be verbose in local rc status
#      rc_status -v -r  ditto and clear the local rc status
#      rc_status -s     display "skipped" and exit with status 3
#      rc_status -u     display "unused" and exit with status 3
#      rc_failed        set local and overall rc status to failed
#      rc_failed <num>  set local and overall rc status to <num>
#      rc_reset         clear local rc status (overall remains)
#      rc_exit          exit appropriate to overall rc status
#      rc_active        checks whether a service is activated by symlinks
#      rc_splash arg    sets the boot splash screen to arg (if active)

. /etc/rc.status
rc_reset

# Return values acc. to LSB for all commands but status:
# 0       - success
# 1       - generic or unspecified error
# 2       - invalid or excess argument(s)
# 3       - unimplemented feature (e.g. "reload")
# 4       - user had insufficient privileges
# 5       - program is not installed
# 6       - program is not configured
# 7       - program is not running
# 8--199  - reserved (8--99 LSB, 100--149 distrib, 150--199 appl)
#
# Note that starting an already running service, stopping
# or restarting a not-running service as well as the restart
# with force-reload (in case signaling is not supported) are
# considered a success.

# ************************************************************************************
# eja: on standard MRIR (Step2,Step3,Step4), eth1 is unused GbE port
#      on Step4 MRIR with 10 GbE card added, eth1 is unused GbE, eth2 is 10 GbE
#      on EJA MRIR++ MkI, eth1-3 are unused GbE, eth4 is 10 GbE

# configure IP address of secondary 1GbE port if desired (comment out if unused)
#ADDR_1G=10.1.1.2 # local net
#NM_1G=255.255.255.0

# configure IP address of 10GbE port if available (comment out if unavailable)
ADDR_10G=10.1.1.2 #local net
NM_10G=255.255.255.0

# ************************************************************************************

case "$1" in
    start)
        echo "eja_config10GbE: Configuring additional network interfaces:"
        
        # configure the built-in secondary 1GbE port if defined
        if [ -n "$ADDR_1G" ] && [ -n "$NM_1G" ]; then
            echo "eja_config10GbE:    Configuring GbE NIC2 (eth1)"
            /sbin/ifconfig eth1 $ADDR_1G netmask $NM_1G up
            if [ $? -ne 0 ]; then
                echo "eja_config10GbE:       Configuring GbE NIC2 failed"
                exit 1
            fi
            echo "eja_config10GbE:       GbE NIC2 configured"
        fi

        # configure the 10GbE port if defined
        FOUND_10GBE=0
        if [ -n "$ADDR_10G" ] && [ -n "$NM_10G" ]; then
            echo "eja_config10GbE:    Attempting to configure 10 GbE NIC3"
            if [ $(/sbin/lspci | grep "Myri-10G" | wc -l) -gt 0 ]; then
                # this is the recommended Myricom PCIe adapter
                if [ $EJA_SYSTEM_TYPE -a $EJA_SYSTEM_TYPE = "EJA_MkI" ]; then
                    echo "eja_config10GbE:       Myricom 10 GbE NIC3 is eth4"
                    ADAPTER=eth4
                else
                    echo "eja_config10GbE:       Myricom 10 GbE NIC3 is eth2"
                    ADAPTER=eth2
                    /sbin/insmod /opt/med/modules/eja_10gbe/dca.ko
                    if [ $? -ne 0 ]; then
                        echo "eja_config10GbE:       Installing dca module failed"
                        exit 1
                    fi
                fi

                /sbin/modprobe firmware_class
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing firmware_class module failed"
                    exit 1
                fi

                echo "eja_config10GbE:       Loading myri10ge kernel module"
                /bin/cp /opt/med/modules/eja_10gbe/myri10ge_*.dat /lib/firmware/
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing firmware binaries failed"
                    exit 1
                fi
                /sbin/insmod /opt/med/modules/eja_10gbe/myri10ge.ko
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing myri10ge module failed"
                    exit 1
                fi
                
                FOUND_10GBE=1
            elif [ $(/sbin/lspci | grep "Intel Corporation 82597EX 10GbE" | wc -l) -gt 0 ]; then
                # this is an old Intel PCI-X adapter (mainly for Step3 systems, but possibly for Step4)
                echo "eja_config10GbE:       Intel PCI-X 10 GbE NIC3 is eth2"
                ADAPTER=eth2
                
                /sbin/insmod /opt/med/modules/eja_10gbe/ixgb.ko
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing ixgb module failed"
                    exit 1
                fi
                
                FOUND_10GBE=2
            elif [ $(/sbin/lspci | grep -e "Intel Corporation 82598 10GbE" -e "Intel Corporation 82598EB 10-Gigabit" -e "Intel Corporation 10 Gigabit BR KX4" -e "Intel Corporation 82599 10 Gigabit" -e "Intel Corporation 82599ES 10-Gigabit" -e "Intel Corporation Ethernet Express Module X520-P2" -e "Intel Corporation 82598EB 10-Gigabit" -e "Intel Corporation Ethernet X520 10GbE" -e "Intel Corporation 82599ES 10 Gigabit" -e "Intel Corporation Ethernet Controller 10-Gigabit X540-AT2" -e "Intel Corporation Ethernet Server Adapter X520-4" -e "Intel Corporation Ethernet Converged Network Adapter X520-Q1" -e "Intel Corporation Ethernet Controller X540" | wc -l) -gt 0 ]; then
                # this is an Intel PCIe adapter
                echo "eja_config10GbE:       Intel PCIe 10 GbE NIC3 is eth2"
                ADAPTER=eth2
                
                /sbin/insmod /opt/med/modules/eja_10gbe/ixgbe.ko
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing ixgbe module failed"
                    exit 1
                fi
                
                FOUND_10GBE=3
            else
                echo "eja_config10GbE:       10 GbE device not found"
                exit 1
            fi
            
            if [ $FOUND_10GBE -ne 0 ]; then
                /sbin/ifconfig $ADAPTER $ADDR_10G netmask $NM_10G mtu 9000 up
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Configuring 10 GbE NIC3 failed"
                    exit 1
                fi
                echo "eja_config10GbE:       10 GbE NIC3 configured"
            fi
        fi
        ;;
    *)
        echo "eja_config10GbE: Usage: $0 {start}"
        exit 1
        ;;
esac
rc_exit
