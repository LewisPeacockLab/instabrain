#!/bin/bash

progname="ejaMBRemoteICE"
pathname="."

# 0.0.0.0 listens on all configured addresses
# can specify a single address to listen on instead
ip="0.0.0.0"
port=10000

# example configuration for single GPU
cputhreads=0
gpudevices=1
gputhreads=1

LD_LIBRARY_PATH=${pathname}
export LD_LIBRARY_PATH

echo Starting ${progname} "->" messages output to local terminal
${pathname}/${progname} $port --address $ip --cpu-threads $cputhreads --gpu-threads $gputhreads --gpu-devices $gpudevices --verbose
