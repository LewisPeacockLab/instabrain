#!/bin/bash
#
# Author: E. Auerbach, CMRR, 2013-14
#
# /opt/med/config/scripts/med.rc.boot/eja_config10GbE.sh
#
# This script configures the 10GbE network adapter installed by the
# local site, which is used for fast remote assisted image recon.
# VD11 version.
#
#
# Shell functions sourced from /etc/rc.status:
#      rc_check         check and set local and overall rc status
#      rc_status        check and set local and overall rc status
#      rc_status -v     ditto but be verbose in local rc status
#      rc_status -v -r  ditto and clear the local rc status
#      rc_status -s     display "skipped" and exit with status 3
#      rc_status -u     display "unused" and exit with status 3
#      rc_failed        set local and overall rc status to failed
#      rc_failed <num>  set local and overall rc status to <num>
#      rc_reset         clear local rc status (overall remains)
#      rc_exit          exit appropriate to overall rc status
#      rc_active        checks whether a service is activated by symlinks
#      rc_splash arg    sets the boot splash screen to arg (if active)

. /etc/rc.status
rc_reset

# Return values acc. to LSB for all commands but status:
# 0       - success
# 1       - generic or unspecified error
# 2       - invalid or excess argument(s)
# 3       - unimplemented feature (e.g. "reload")
# 4       - user had insufficient privileges
# 5       - program is not installed
# 6       - program is not configured
# 7       - program is not running
# 8--199  - reserved (8--99 LSB, 100--149 distrib, 150--199 appl)
#
# Note that starting an already running service, stopping
# or restarting a not-running service as well as the restart
# with force-reload (in case signaling is not supported) are
# considered a success.

# ************************************************************************************
# eja: On VD11 MARS, eth0 is the internal network, eth1 is can24.
#      The first installed additional network card will be eth2.
#      NOTE: If cards are changed, delete /etc/udev/rules.d/70-persistent-net.rules
#            or reinstall the MCIR to reset this mapping, otherwise each new card will
#            be mapped to eth3, eth4, etc. This script just expects it to be eth2.

# configure IP address of 10GbE port if available (comment out if unavailable)
ADDR_10G=10.1.1.2 #local net
NM_10G=255.255.255.0

# ************************************************************************************

case "$1" in
    start)
        echo "eja_config10GbE: Configuring additional network interfaces:"
        
        # configure the 10GbE port if defined
        FOUND_10GBE=0
        if [ -n "$ADDR_10G" ] && [ -n "$NM_10G" ]; then
            echo "eja_config10GbE:    Attempting to configure 10 GbE NIC3"
            if [ $(/sbin/lspci | grep "Myri-10G" | wc -l) -gt 0 ]; then
                # this is the recommended Myricom PCIe adapter
                echo "eja_config10GbE:       Myricom 10 GbE NIC is eth2"
                ADAPTER=eth2

                echo "eja_config10GbE:       Loading myri10ge kernel module"
                /bin/cp /opt/med/modules/eja_10gbe/myri10ge_*.dat /lib/firmware/
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing firmware binaries failed"
                    exit 1
                fi
                /sbin/insmod /opt/med/modules/eja_10gbe/myri10ge.ko
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Installing myri10ge module failed"
                    exit 1
                fi
                
                FOUND_10GBE=1
            else
                echo "eja_config10GbE:       10 GbE device not found"
                exit 1
            fi
            
            if [ $FOUND_10GBE -ne 0 ]; then
                /sbin/ifconfig $ADAPTER $ADDR_10G netmask $NM_10G mtu 9000 up
                if [ $? -ne 0 ]; then
                    echo "eja_config10GbE:       Configuring 10 GbE NIC3 failed"
                    exit 1
                fi
                echo "eja_config10GbE:       10 GbE NIC3 configured"
            fi
        fi
        ;;
    *)
        echo "eja_config10GbE: Usage: $0 {start}"
        exit 1
        ;;
esac
rc_exit
