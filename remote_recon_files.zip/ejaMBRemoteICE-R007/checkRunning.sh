#!/bin/bash

progname="ejaMBRemoteICE"
pathname="/home/realtime/remoteServer/ejaMBRemoteICE-R007"
logname=/var/log/${progname}.log

# 0.0.0.0 listens on all configured addresses
# can specify a single address to listen on instead
ip="0.0.0.0"
port=10000

# example configuration for single GPU
cputhreads=1
gpudevices=0
gputhreads=0

cmdline="$pathname/$progname $port --address $ip --cpu-threads $cputhreads --gpu-threads $gputhreads --gpu-devices $gpudevices --verbose --logfile $logname"

checkactive=$(/usr/bin/pgrep -f "$cmdline")

if [ "$checkactive" = "" ]; then
   echo "$progname found down on $(date +%m-%d-%Y)"
   echo "(re)starting $progname"
   LD_LIBRARY_PATH=${pathname}
   export LD_LIBRARY_PATH
   $cmdline &
#else
   echo "$progname is already running (pid = $checkactive)"
fi
