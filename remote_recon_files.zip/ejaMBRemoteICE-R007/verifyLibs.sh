#!/bin/bash

progname="ejaMBRemoteICE"
pathname="."

LD_LIBRARY_PATH=${pathname}
export LD_LIBRARY_PATH

ldd ${progname}
